// File: src/store/useUserStore.js

import { create } from 'zustand';
import { storage } from '../services/storage';

export const useUserStore = create((set) => ({
  user: null,
  isAuthenticated: false,

  // Chamado no login ou splash screen
  hydrate: async () => {
    const user = await storage.getUser();
    const token = await storage.getToken();
    if (user && token) {
      set({ user, isAuthenticated: true });
    }
  },

  login: (user, token) => {
    storage.setUser(user);
    storage.setToken(token);
    set({ user, isAuthenticated: true });
  },

  logout: async () => {
    await storage.clearAll();
    set({ user: null, isAuthenticated: false });
  }
}));