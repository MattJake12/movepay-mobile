// File: firebase-config.js

// mobile/firebase-config.js
// Configuração do Firebase para React Native/Expo

export const firebaseConfig = {
  apiKey: "AIzaSyDsjwVedzNB31pq3iY6ki0tTMQs9VTxFvA",
  authDomain: "movepay-c6651.firebaseapp.com",
  projectId: "movepay-c6651",
  storageBucket: "movepay-c6651.firebasestorage.app",
  messagingSenderId: "584123658590",
  appId: "1:584123658590:web:8ee35e4c9386d5fe2b5fcf",
  measurementId: "G-W7SEHF5WMT"
};

export default firebaseConfig;
