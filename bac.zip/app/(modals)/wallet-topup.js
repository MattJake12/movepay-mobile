import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';
import { X, Smartphone, CreditCard, CheckCircle2 } from 'lucide-react-native';
import { useWallet } from '../../src/hooks/useWallet';
import { colors, spacing, fontSize, fontWeight } from '../../src/theme/theme';

export default function WalletTopUp() {
  const router = useRouter();
  const { topUp } = useWallet();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('MULTICAIXA');

  const handleTopUp = async () => {
    if (!amount || parseInt(amount) < 100) {
      Alert.alert('Erro', 'Mínimo de 100 Kz');
      return;
    }

    topUp.mutate(
      { amount: parseInt(amount), method },
      {
        onSuccess: (result) => {
          Alert.alert(
            'Sucesso!',
            `${result.data.pointsAdded} pontos adicionados à sua carteira`,
            [
              {
                text: 'OK',
                onPress: () => router.back(),
              },
            ]
          );
        },
        onError: (err) => {
          const message =
            err.response?.data?.message || 'Falha ao carregar a carteira';
          Alert.alert('Erro', message);
        },
      }
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <View style={{ flex: 1, padding: spacing[6] }}>
        {/* HEADER */}
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: spacing[10],
          }}
        >
          <Text
            style={{
              fontSize: fontSize['2xl'],
              fontWeight: fontWeight.bold,
              color: colors.slate[900],
            }}
          >
            Carregar Carteira
          </Text>
          <TouchableOpacity onPress={() => router.back()}>
            <X size={24} color={colors.slate[400]} />
          </TouchableOpacity>
        </View>

        {/* AMOUNT INPUT */}
        <Text
          style={{
            fontSize: fontSize.xs,
            fontWeight: fontWeight.bold,
            color: colors.slate[500],
            textTransform: 'uppercase',
            marginBottom: spacing[3],
            letterSpacing: 1,
          }}
        >
          Valor a Carregar (Kz)
        </Text>

        <TextInput
          placeholder="0"
          keyboardType="numeric"
          value={amount}
          onChangeText={setAmount}
          autoFocus
          style={{
            fontSize: 48,
            fontWeight: fontWeight.bold,
            color: colors.brand[600],
            marginBottom: spacing[8],
            borderBottomWidth: 2,
            borderBottomColor: colors.brand[200],
            paddingBottom: spacing[4],
          }}
        />

        {/* MÉTODO DE PAGAMENTO */}
        <Text
          style={{
            fontSize: fontSize.xs,
            fontWeight: fontWeight.bold,
            color: colors.slate[500],
            textTransform: 'uppercase',
            marginBottom: spacing[3],
            letterSpacing: 1,
          }}
        >
          Método de Pagamento
        </Text>

        {/* MULTICAIXA */}
        <TouchableOpacity
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            padding: spacing[4],
            borderRadius: 16,
            borderWidth: 2,
            borderColor:
              method === 'MULTICAIXA' ? colors.brand[600] : colors.slate[200],
            backgroundColor:
              method === 'MULTICAIXA' ? colors.brand[50] : colors.white,
            marginBottom: spacing[3],
          }}
          onPress={() => setMethod('MULTICAIXA')}
        >
          <Smartphone size={24} color={colors.blue[600]} />
          <Text
            style={{
              fontWeight: fontWeight.bold,
              fontSize: fontSize.base,
              marginLeft: spacing[3],
              flex: 1,
              color: colors.slate[800],
            }}
          >
            Multicaixa Express
          </Text>
          {method === 'MULTICAIXA' && (
            <CheckCircle2 size={20} color={colors.brand[600]} />
          )}
        </TouchableOpacity>

        {/* CARD */}
        <TouchableOpacity
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            padding: spacing[4],
            borderRadius: 16,
            borderWidth: 2,
            borderColor: method === 'CARD' ? colors.brand[600] : colors.slate[200],
            backgroundColor: method === 'CARD' ? colors.brand[50] : colors.white,
            marginBottom: spacing[8],
          }}
          onPress={() => setMethod('CARD')}
        >
          <CreditCard size={24} color={colors.slate[600]} />
          <Text
            style={{
              fontWeight: fontWeight.bold,
              fontSize: fontSize.base,
              marginLeft: spacing[3],
              flex: 1,
              color: colors.slate[800],
            }}
          >
            Cartão VISA / GPO
          </Text>
          {method === 'CARD' && (
            <CheckCircle2 size={20} color={colors.brand[600]} />
          )}
        </TouchableOpacity>

        {/* BUTTON */}
        <TouchableOpacity
          style={{
            backgroundColor: colors.brand[600],
            padding: spacing[5],
            borderRadius: 16,
            alignItems: 'center',
            marginTop: 'auto',
          }}
          onPress={handleTopUp}
          disabled={topUp.isPending}
        >
          {topUp.isPending ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text
              style={{
                color: colors.white,
                fontWeight: fontWeight.bold,
                fontSize: fontSize.base,
              }}
            >
              Confirmar Pagamento
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
