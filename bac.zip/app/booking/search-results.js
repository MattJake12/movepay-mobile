// File: app/booking/search-results.js

import React, { useState } from 'react';
import { FlatList, View, Text, TouchableOpacity, ActivityIndicator, SafeAreaView } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import styled from 'styled-components/native';
import { ArrowLeft, MapPin, Clock, Users, SlidersHorizontal } from 'lucide-react-native';
import api from '../../src/lib/api';
import { colors, spacing, fontSize, fontWeight, shadows } from '../../src/theme/theme';

const formatKz = (v) => new Intl.NumberFormat('pt-AO', { style: 'currency', currency: 'AOA', minimumFractionDigits: 0 }).format(v);

// ===== STYLED COMPONENTS =====

const Container = styled.View`
  flex: 1;
  background-color: ${colors.slate[50]};
`;

const Header = styled.View`
  background-color: ${colors.white};
  padding: ${spacing[6]}px;
  padding-top: ${spacing[4]}px;
  border-bottom-width: 1px;
  border-bottom-color: ${colors.slate[200]};
  flex-direction: row;
  align-items: center;
  gap: ${spacing[3]}px;
`;

const HeaderTitle = styled.Text`
  font-size: ${fontSize.lg}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
  flex: 1;
`;

const BackButton = styled.TouchableOpacity`
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background-color: ${colors.slate[100]};
  justify-content: center;
  align-items: center;
`;

const FilterButton = styled.TouchableOpacity`
  padding: ${spacing[2]}px;
  background-color: ${colors.slate[100]};
  border-radius: 8px;
  justify-content: center;
  align-items: center;
`;

const TripCard = styled.TouchableOpacity`
  background-color: ${colors.white};
  margin: ${spacing[3]}px ${spacing[4]}px;
  padding: ${spacing[4]}px;
  border-radius: 12px;
  border-width: 1px;
  border-color: ${colors.slate[200]};
  ${shadows.sm}
`;

const RouteText = styled.Text`
  font-size: ${fontSize.base}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
  margin-bottom: ${spacing[2]}px;
`;

const InfoRow = styled.View`
  flex-direction: row;
  align-items: center;
  gap: ${spacing[2]}px;
  margin-bottom: ${spacing[2]}px;
`;

const InfoText = styled.Text`
  font-size: ${fontSize.sm}px;
  color: ${colors.slate[600]};
`;

const PriceText = styled.Text`
  font-size: ${fontSize.lg}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.brand[600]};
  margin-top: ${spacing[2]}px;
`;

const SeatsText = styled.Text`
  font-size: ${fontSize.xs}px;
  color: ${colors.slate[500]};
`;

const EmptyContainer = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  padding: ${spacing[6]}px;
`;

const EmptyText = styled.Text`
  font-size: ${fontSize.base}px;
  color: ${colors.slate[500]};
  text-align: center;
`;

export default function SearchResultsScreen() {
  const router = useRouter();
  const { origin, destination, date } = useLocalSearchParams();

  const { data: trips, isLoading, error } = useQuery({
    queryKey: ['trips', origin, destination, date],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (origin) params.append('origin', origin);
      if (destination) params.append('destination', destination);
      if (date) params.append('date', date);
      
      const res = await api.get(`/trips?${params.toString()}`);
      return res.data.data || [];
    }
  });

  const handleTripPress = (tripId) => {
    router.push(`/booking/${tripId}`);
  };

  if (isLoading) {
    return (
      <Container>
        <Header>
          <BackButton onPress={() => router.back()}>
            <ArrowLeft size={20} color={colors.slate[600]} />
          </BackButton>
          <HeaderTitle>Resultados da Busca</HeaderTitle>
        </Header>
        <EmptyContainer>
          <ActivityIndicator size="large" color={colors.brand[600]} />
        </EmptyContainer>
      </Container>
    );
  }

  return (
    <Container>
      <Header>
        <BackButton onPress={() => router.back()}>
          <ArrowLeft size={20} color={colors.slate[600]} />
        </BackButton>
        <HeaderTitle>
          {trips?.length || 0} {(trips?.length === 1) ? 'Viagem' : 'Viagens'}
        </HeaderTitle>
        {/* ✅ MISSÃO 2A: Botão de Filtro com ícone SlidersHorizontal */}
        <FilterButton onPress={() => router.push('/(modals)/filter')}>
          <SlidersHorizontal size={20} color={colors.slate[700]} />
        </FilterButton>
      </Header>

      {trips && trips.length > 0 ? (
        <FlatList
          data={trips}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: spacing[6] }}
          renderItem={({ item }) => (
            <TripCard onPress={() => handleTripPress(item.id)}>
              <RouteText>
                {item.origin} → {item.destination}
              </RouteText>

              <InfoRow>
                <Clock size={16} color={colors.slate[500]} />
                <InfoText>
                  {new Date(item.departureTime).toLocaleTimeString('pt-AO', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                  {' '}
                  (
                  {new Date(item.arrivalTime).toLocaleTimeString('pt-AO', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                  )
                </InfoText>
              </InfoRow>

              <InfoRow>
                <MapPin size={16} color={colors.slate[500]} />
                <InfoText>{item.company?.name || 'Operadora desconhecida'}</InfoText>
              </InfoRow>

              <InfoRow>
                <Users size={16} color={colors.slate[500]} />
                <SeatsText>
                  {item.availableSeats} {(item.availableSeats === 1) ? 'lugar' : 'lugares'} disponível{(item.availableSeats === 1) ? '' : 'is'}
                </SeatsText>
              </InfoRow>

              <PriceText>{formatKz(item.price)}</PriceText>
            </TripCard>
          )}
        />
      ) : (
        <EmptyContainer>
          <EmptyText>Nenhuma viagem encontrada.{'\n'}Tente outros filtros.</EmptyText>
        </EmptyContainer>
      )}
    </Container>
  );
}
