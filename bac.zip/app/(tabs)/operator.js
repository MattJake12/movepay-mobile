// File: app/(tabs)/operator.js

import React, { useState } from 'react';
import { ScrollView, RefreshControl, StatusBar, View, ActivityIndicator, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import styled from 'styled-components/native';
import { useQuery } from '@tanstack/react-query';
import { 
  TrendingUp, 
  Users, 
  Bus, 
  QrCode, 
  Calendar, 
  AlertCircle,
  ChevronRight,
  DollarSign,
  FileText,
  CheckCircle2
} from 'lucide-react-native';
import api from '../../src/lib/api';
import { colors, spacing, fontSize, fontWeight, shadows } from '../../src/theme/theme';

// ===== STYLED COMPONENTS =====

const Container = styled.SafeAreaView`
  flex: 1;
  background-color: ${colors.slate[50]};
`;

const Header = styled.View`
  padding: ${spacing[6]}px;
  background-color: ${colors.white};
  border-bottom-width: 1px;
  border-bottom-color: ${colors.slate[100]};
`;

const Title = styled.Text`
  font-size: ${fontSize['2xl']}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
`;

const Subtitle = styled.Text`
  font-size: ${fontSize.sm}px;
  color: ${colors.slate[500]};
  margin-top: 4px;
`;

const Content = styled.ScrollView`
  flex: 1;
  padding: ${spacing[6]}px;
`;

// Stats Grid
const Grid = styled.View`
  flex-direction: row;
  gap: ${spacing[4]}px;
  margin-bottom: ${spacing[4]}px;
`;

const StatCard = styled.View`
  flex: 1;
  background-color: ${colors.white};
  padding: ${spacing[4]}px;
  border-radius: 16px;
  border-width: 1px;
  border-color: ${colors.slate[100]};
  ${shadows.sm}
`;

const IconBox = styled.View`
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background-color: ${props => props.bg};
  align-items: center;
  justify-content: center;
  margin-bottom: ${spacing[2]}px;
`;

const StatValue = styled.Text`
  font-size: ${fontSize.xl}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
`;

const StatLabel = styled.Text`
  font-size: 10px;
  color: ${colors.slate[500]};
  font-weight: ${fontWeight.bold};
  text-transform: uppercase;
  margin-top: 2px;
`;

// Section
const SectionHeader = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-top: ${spacing[4]}px;
  margin-bottom: ${spacing[4]}px;
`;

const SectionTitle = styled.Text`
  font-size: ${fontSize.lg}px;
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
`;

// Trip Item (Operator View)
const TripItem = styled.TouchableOpacity`
  background-color: ${colors.white};
  border-radius: 12px;
  padding: ${spacing[4]}px;
  margin-bottom: ${spacing[3]}px;
  border-width: 1px;
  border-color: ${colors.slate[200]};
  flex-direction: row;
  align-items: center;
`;

const TripTime = styled.View`
  align-items: center;
  margin-right: ${spacing[4]}px;
  min-width: 48px;
`;

const TimeText = styled.Text`
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[900]};
`;

const DateText = styled.Text`
  font-size: 10px;
  color: ${colors.slate[500]};
`;

const TripInfo = styled.View`
  flex: 1;
`;

const RouteText = styled.Text`
  font-weight: ${fontWeight.bold};
  color: ${colors.slate[800]};
  font-size: ${fontSize.base}px;
`;

const BusInfo = styled.Text`
  font-size: ${fontSize.xs}px;
  color: ${colors.slate[500]};
  margin-top: 2px;
`;

const OccupancyBadge = styled.View`
  background-color: ${props => props.full ? colors.red[50] : colors.emerald[50]};
  padding: 4px 8px;
  border-radius: 6px;
  align-items: center;
`;

const OccupancyText = styled.Text`
  font-weight: ${fontWeight.bold};
  color: ${props => props.full ? colors.red[600] : colors.emerald[600]};
  font-size: ${fontSize.xs}px;
`;

// Action Buttons (Manifesto + Check-in)
const ActionButtons = styled.View`
  flex-direction: row;
  gap: ${spacing[2]}px;
  margin-left: ${spacing[2]}px;
`;

const ActionButton = styled.TouchableOpacity`
  padding: 6px 10px;
  border-radius: 8px;
  background-color: ${props => props.primary ? colors.brand[600] : colors.slate[100]};
  align-items: center;
  justify-content: center;
`;

// Scanner Button
const FabButton = styled.TouchableOpacity`
  position: absolute;
  bottom: 24px;
  right: 24px;
  width: 56px;
  const router = useRouter();
  height: 56px;
  border-radius: 28px;
  background-color: ${colors.brand[600]};
  align-items: center;
  justify-content: center;
  ${shadows.lg}
`;

const LoadingContainer = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`;

export default function OperatorScreen() {
  const [refreshing, setRefreshing] = useState(false);

  // Mock Data (Substituir por useQuery real)
  const { data: dashboard, isLoading } = useQuery({
    queryKey: ['operator-dashboard'],
    queryFn: async () => {
      // Simulação
      return {
        stats: {
          todayTrips: 12,
          passengers: 342,
          revenue: '1.2M'
        },
        trips: [
          { id: 1, time: '08:00', origin: 'Luanda', destination: 'Benguela', bus: 'Volvo B12', seats: '42/45' },
          { id: 2, time: '10:30', origin: 'Luanda', destination: 'Huambo', bus: 'Scania K', seats: '45/45' },
          { id: 3, time: '14:00', origin: 'Luanda', destination: 'Soyo', bus: 'Marcopolo', seats: '12/45' },
        ]
      };
    }
  });

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  if (isLoading) {
    return (
      <LoadingContainer>
        <ActivityIndicator size="large" color={colors.brand[600]} />
      </LoadingContainer>
    );
  }

  return (
    <Container>
      <StatusBar barStyle="dark-content" />
      
      <Header>
        <Title>Painel Operacional</Title>
        <Subtitle>Visão geral do dia</Subtitle>
      </Header>

      <Content
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* STATS */}
        <Grid>
          <StatCard>
            <IconBox bg={colors.blue[50]}>
              <Bus size={18} color={colors.blue[600]} />
            </IconBox>
            <StatValue>{dashboard?.stats.todayTrips}</StatValue>
            <StatLabel>Viagens Hoje</StatLabel>
          </StatCard>
          
          <StatCard>
            <IconBox bg={colors.orange[50]}>
              <Users size={18} color={colors.orange[600]} />
            </IconBox>
            <StatValue>{dashboard?.stats.passengers}</StatValue>
            <StatLabel>Passageiros</StatLabel>
          </StatCard>
        </Grid>

        <Grid>
          <StatCard>
            <IconBox bg={colors.green[50]}>
              <DollarSign size={18} color={colors.green[600]} />
            </IconBox>
            <StatValue>{dashboard?.stats.revenue}</StatValue>
            <StatLabel>Receita (Kz)</StatLabel>
          </StatCard>
        </Grid>

        {/* LISTA DE VIAGENS */}
        <SectionHeader>
          <SectionTitle>Próximas Partidas</SectionTitle>
          <Calendar size={20} color={colors.slate[400]} />
        </SectionHeader>

        {dashboard?.trips.map((trip) => (
          <TripItem key={trip.id} activeOpacity={0.7}>
            <TripTime>
              <TimeText>{trip.time}</TimeText>
              <DateText>Hoje</DateText>
            </TripTime>
            
            <TripInfo>
              <RouteText>{trip.origin} ➔ {trip.destination}</RouteText>
              <BusInfo>{trip.bus}</BusInfo>
            </TripInfo>

            <OccupancyBadge full={trip.seats.startsWith('45')}>
              <OccupancyText full={trip.seats.startsWith('45')}>{trip.seats}</OccupancyText>
            </OccupancyBadge>

            {/* Action Buttons */}
            <ActionButtons>
              <ActionButton 
                primary
                onPress={() => router.push(`/driver/manifest?tripId=${trip.id}`)}
                activeOpacity={0.7}
              >
                <FileText size={16} color={colors.white} />
              </ActionButton>
              <ActionButton 
                onPress={() => router.push(`/driver/check-in?tripId=${trip.id}`)}
                activeOpacity={0.7}
              >
                <CheckCircle2 size={16} color={colors.slate[600]} />
              </ActionButton>
            </ActionButtons>
            
            <ChevronRight size={16} color={colors.slate[300]} style={{ marginLeft: 8 }} />
          </TripItem>
        ))}

        <View style={{ height: 80 }} />
      </Content>

      {/* FAB SCANNER */}
      <FabButton>
        <QrCode size={24} color={colors.white} />
      </FabButton>
    </Container>
  );
}