// File: app/(tabs)/validation.js

import React, { useState } from 'react';
import { View, StatusBar, Alert } from 'react-native';
import styled from 'styled-components/native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { ScanLine, Zap, ZapOff, X } from 'lucide-react-native';
import { colors, spacing, fontSize, fontWeight } from '../../src/theme/theme';

// ===== STYLED COMPONENTS =====

const Container = styled.View`
  flex: 1;
  background-color: ${colors.black};
`;

const CameraWrapper = styled(CameraView)`
  flex: 1;
`;

const Overlay = styled.View`
  flex: 1;
  background-color: rgba(0,0,0,0.5);
  justify-content: center;
  align-items: center;
`;

// Buraco transparente (Máscara simulada com bordas)
const ScanFrame = styled.View`
  width: 280px;
  height: 280px;
  border-radius: 24px;
  border-width: 2px;
  border-color: ${colors.white};
  background-color: transparent;
  overflow: hidden;
  position: relative;
`;

const Corner = styled.View`
  position: absolute;
  width: 40px;
  height: 40px;
  border-color: ${colors.brand[500]};
  border-width: 4px;
  border-radius: 4px;
`;

const Instructions = styled.View`
  position: absolute;
  bottom: 80px;
  left: 0;
  right: 0;
  align-items: center;
`;

const TextInstruction = styled.Text`
  color: ${colors.white};
  font-size: ${fontSize.base}px;
  font-weight: ${fontWeight.bold};
  text-align: center;
  margin-bottom: 8px;
`;

const SubText = styled.Text`
  color: ${colors.slate[300]};
  font-size: ${fontSize.sm}px;
`;

const Controls = styled.View`
  position: absolute;
  top: 60px;
  right: 20px;
  gap: 16px;
`;

const ControlButton = styled.TouchableOpacity`
  width: 44px;
  height: 44px;
  border-radius: 22px;
  background-color: rgba(255,255,255,0.2);
  align-items: center;
  justify-content: center;
`;

const PermissionView = styled.View`
  flex: 1;
  background-color: ${colors.slate[900]};
  align-items: center;
  justify-content: center;
  padding: ${spacing[6]}px;
`;

const PermissionText = styled.Text`
  color: ${colors.white};
  font-size: ${fontSize.lg}px;
  text-align: center;
  margin-bottom: ${spacing[4]}px;
`;

const Button = styled.TouchableOpacity`
  background-color: ${colors.brand[600]};
  padding: 16px 32px;
  border-radius: 12px;
`;

const ButtonText = styled.Text`
  color: ${colors.white};
  font-weight: bold;
`;

export default function ValidationScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [torch, setTorch] = useState(false);

  if (!permission) return <View />;

  if (!permission.granted) {
    return (
      <PermissionView>
        <PermissionText>Precisamos de acesso à câmera para validar bilhetes.</PermissionText>
        <Button onPress={requestPermission}>
          <ButtonText>Conceder Permissão</ButtonText>
        </Button>
      </PermissionView>
    );
  }

  const handleBarCodeScanned = ({ data }) => {
    setScanned(true);
    Alert.alert(
      "Bilhete Validado", 
      `Código: ${data}`,
      [{ text: "OK", onPress: () => setScanned(false) }]
    );
  };

  return (
    <Container>
      <StatusBar barStyle="light-content" />
      <CameraWrapper 
        facing="back" 
        enableTorch={torch}
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
      >
        <Overlay>
          <ScanFrame>
            {/* Cantos Decorativos */}
            <Corner style={{ top: 0, left: 0, borderRightWidth: 0, borderBottomWidth: 0 }} />
            <Corner style={{ top: 0, right: 0, borderLeftWidth: 0, borderBottomWidth: 0 }} />
            <Corner style={{ bottom: 0, left: 0, borderRightWidth: 0, borderTopWidth: 0 }} />
            <Corner style={{ bottom: 0, right: 0, borderLeftWidth: 0, borderTopWidth: 0 }} />
            
            {/* Linha de Scan Animada (Simulada visualmente com ScanLine Icon no centro) */}
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', opacity: 0.5 }}>
              <ScanLine size={150} color={colors.brand[500]} strokeWidth={0.5} />
            </View>
          </ScanFrame>
        </Overlay>

        <Controls>
          <ControlButton onPress={() => setTorch(!torch)}>
            {torch ? <Zap size={20} color="#fbbf24" /> : <ZapOff size={20} color="#fff" />}
          </ControlButton>
        </Controls>

        <Instructions>
          <TextInstruction>Validar Embarque</TextInstruction>
          <SubText>Aponte para o QR Code do passageiro</SubText>
        </Instructions>
      </CameraWrapper>
    </Container>
  );
}