// File: app/(tabs)/home-styled.js

// app/(tabs)/home-styled.js - VERSION COM STYLED-COMPONENTS
import React, { useState, useEffect } from 'react';
import { RefreshControl, StatusBar, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  MapPin,
  Calendar,
  Search,
  Bell,
  Wallet,
  Bus,
  Utensils,
  Package,
  Star,
  ArrowRight,
  TrendingUp,
  Clock,
} from 'lucide-react-native';
import { useQuery } from '@tanstack/react-query';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styled from 'styled-components/native';
import api from '../../src/lib/api';
import { useCompaniesQuery } from '../../src/hooks/useCompanies';
import { useRecommendations } from '../../src/hooks/useRecommendations';
import { RecommendedFeed } from '../../src/components/home/RecommendedFeed';
import { getTripStatusLabel, getTripStatusColor, getTripStatusTextColor } from '../../src/lib/tripStatus';
import { colors, spacing, fontSize, fontWeight, borderRadius, shadows } from '../../src/theme/theme';

const formatKz = (value) => {
  return new Intl.NumberFormat('pt-AO', {
    style: 'currency',
    currency: 'AOA',
    minimumFractionDigits: 0,
  }).format(value);
};

// ===== STYLED COMPONENTS =====
const Container = styled.View`
  flex: 1;
  background-color: ${colors.slate[50]};
`;

const GradientBackgroundContainer = styled.View`
  position: absolute;
  top: 0;
  width: 100%;
  height: 280px;
`;

const GradientBg = styled(LinearGradient)`
  width: 100%;
  height: 100%;
  border-bottom-left-radius: 40px;
  border-bottom-right-radius: 40px;
`;

const DecorativeCircle = styled.View`
  position: absolute;
  border-radius: 9999px;
  background-color: ${props => props.opacity};
`;

const SafeAreaContainer = styled.SafeAreaView`
  flex: 1;
`;

const ScrollViewContainer = styled.ScrollView`
  flex: 1;
`;

const HeaderRow = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px 0 24px;
  margin-bottom: 24px;
`;

const HeaderLeft = styled.View``;

const HeaderLeftSmall = styled.Text`
  color: ${colors.brand[100]};
  font-weight: 500;
  font-size: ${fontSize.sm}px;
  margin-bottom: 4px;
`;

const HeaderLeftLarge = styled.Text`
  color: ${colors.white};
  font-weight: bold;
  font-size: ${fontSize['2xl']}px;
`;

const HeaderRight = styled.View`
  flex-direction: row;
  gap: 12px;
`;

const IconButton = styled.TouchableOpacity`
  width: 40px;
  height: 40px;
  background-color: rgba(255, 255, 255, 0.1);
  border-radius: 20px;
  align-items: center;
  justify-content: center;
  border-width: 1px;
  border-color: rgba(255, 255, 255, 0.1);
`;

const NotificationBadge = styled.View`
  position: absolute;
  top: 8px;
  right: 10px;
  width: 8px;
  height: 8px;
  background-color: ${colors.red[500]};
  border-radius: 4px;
  border-width: 1px;
  border-color: rgba(255, 255, 255, 0.2);
`;

const SearchWidget = styled.View`
  margin-horizontal: 24px;
  background-color: ${colors.white};
  border-radius: 24px;
  padding: 20px;
  margin-bottom: 32px;
  ${shadows.lg}
`;

const TabContainer = styled.View`
  flex-direction: row;
  margin-bottom: 16px;
  border-bottom-width: 1px;
  border-bottom-color: ${colors.slate[100]};
  padding-bottom: 8px;
`;

const Tab = styled.TouchableOpacity`
  margin-right: 24px;
  padding-bottom: 8px;
  border-bottom-width: ${props => props.active ? 2 : 0}px;
  border-bottom-color: ${props => props.active ? colors.brand[600] : 'transparent'};
`;

const TabText = styled.Text`
  color: ${props => props.active ? colors.brand[600] : colors.slate[400]};
  font-weight: ${props => props.active ? 'bold' : '500'};
  font-size: ${fontSize.sm}px;
`;

const InputsContainer = styled.View`
  gap: 12px;
  position: relative;
`;

const DottedLine = styled.View`
  position: absolute;
  left: 14px;
  top: 32px;
  bottom: 32px;
  width: 2px;
  border-left-width: 2px;
  border-left-color: ${colors.slate[200]};
  border-style: dashed;
  z-index: 0;
`;

const InputButton = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  background-color: ${colors.slate[100]};
  padding: 14px;
  border-radius: 12px;
  border-width: 1px;
  border-color: ${colors.slate[100]};
  z-index: 10;
`;

const InputDot = styled.View`
  width: 8px;
  height: 8px;
  border-radius: 4px;
  background-color: ${props => props.color};
  margin-right: 12px;
  margin-left: 4px;
`;

const InputLabel = styled.Text`
  font-size: ${fontSize.xs}px;
  color: ${colors.slate[400]};
  font-weight: 500;
  text-transform: uppercase;
`;

const InputValue = styled.Text`
  font-size: ${fontSize.base}px;
  color: ${props => props.muted ? colors.slate[400] : colors.slate[800]};
  font-weight: bold;
`;

const DatePassengersRow = styled.View`
  flex-direction: row;
  gap: 12px;
  margin-top: 4px;
`;

const DatePassengerButton = styled.TouchableOpacity`
  flex: 1;
  flex-direction: row;
  align-items: center;
  background-color: ${colors.slate[100]};
  padding: 12px;
  border-radius: 12px;
  border-width: 1px;
  border-color: ${colors.slate[100]};
`;

const SearchButton = styled.TouchableOpacity`
  background-color: ${colors.brand[600]};
  border-radius: 12px;
  padding: 16px;
  margin-top: 8px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  ${shadows.lg}
`;

const SearchButtonText = styled.Text`
  color: ${colors.white};
  font-weight: bold;
  font-size: ${fontSize.base}px;
  margin-left: 8px;
`;

export default function HomeScreen() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('bus');

  useEffect(() => {
    const loadUser = async () => {
      const userData = await AsyncStorage.getItem('movepay_user');
      if (userData) setUser(JSON.parse(userData));
    };
    loadUser();
  }, []);

  const { data: trips, isLoading, refetch } = useQuery({
    queryKey: ['trips-home'],
    queryFn: async () => {
      const res = await api.get('/trips');
      return res.data.data;
    },
  });

  const { data: companies, isLoading: companiesLoading } = useCompaniesQuery();

  const onRefresh = async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  };

  const handleStartSearch = () => {
    router.push('/booking/search-results');
  };

  return (
    <Container>
      <StatusBar barStyle="light-content" />

      {/* Background Gradient */}
      <GradientBackgroundContainer>
        <GradientBg colors={['#4c1d95', '#6d28d9', '#7c3aed']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          <DecorativeCircle opacity="rgba(255,255,255,0.05)" style={{ top: 40, left: -80, width: 160, height: 160 }} />
          <DecorativeCircle opacity="rgba(167,139,250,0.1)" style={{ bottom: 80, right: -80, width: 240, height: 240 }} />
        </GradientBg>
      </GradientBackgroundContainer>

      <SafeAreaContainer edges={['top']}>
        <ScrollViewContainer
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />}
          contentContainerStyle={{ paddingBottom: 100 }}
        >
          {/* Header */}
          <HeaderRow>
            <HeaderLeft>
              <HeaderLeftSmall>Bom dia,</HeaderLeftSmall>
              <HeaderLeftLarge>{user?.name?.split(' ')[0] || 'Viajante'} 👋</HeaderLeftLarge>
            </HeaderLeft>
            <HeaderRight>
              <IconButton>
                <Wallet size={20} color={colors.white} />
              </IconButton>
              <IconButton>
                <Bell size={20} color={colors.white} />
                <NotificationBadge />
              </IconButton>
            </HeaderRight>
          </HeaderRow>

          {/* Search Widget */}
          <SearchWidget>
            <TabContainer>
              <Tab active={activeTab === 'bus'} onPress={() => setActiveTab('bus')}>
                <TabText active={activeTab === 'bus'}>Autocarro</TabText>
              </Tab>
              <Tab active={activeTab === 'rental'} onPress={() => setActiveTab('rental')}>
                <TabText active={activeTab === 'rental'}>Aluguer</TabText>
              </Tab>
              <Tab active={activeTab === 'parcels'} onPress={() => setActiveTab('parcels')}>
                <TabText active={activeTab === 'parcels'}>Encomendas</TabText>
              </Tab>
            </TabContainer>

            <InputsContainer>
              <DottedLine />
              
              <InputButton onPress={handleStartSearch}>
                <InputDot color={colors.slate[400]} />
                <InputLabel>Origem</InputLabel>
                <InputValue>Luanda</InputValue>
              </InputButton>

              <InputButton onPress={handleStartSearch}>
                <InputDot color={colors.brand[500]} />
                <InputLabel>Destino</InputLabel>
                <InputValue muted>Para onde vamos?</InputValue>
              </InputButton>

              <DatePassengersRow>
                <DatePassengerButton>
                  <Calendar size={16} color={colors.slate[400]} />
                  <InputValue style={{ marginLeft: 8 }}>Hoje</InputValue>
                </DatePassengerButton>
                <DatePassengerButton>
                  <InputValue style={{ textAlign: 'center', flex: 1 }}>1 Passageiro</InputValue>
                </DatePassengerButton>
              </DatePassengersRow>

              <SearchButton onPress={handleStartSearch}>
                <Search size={20} color={colors.white} />
                <SearchButtonText>Buscar Bilhetes</SearchButtonText>
              </SearchButton>
            </InputsContainer>
          </SearchWidget>

          {/* Recommended Feed */}
          <RecommendedFeed />
        </ScrollViewContainer>
      </SafeAreaContainer>
    </Container>
  );
}
